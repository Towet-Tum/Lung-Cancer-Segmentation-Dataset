# lung cancer > 2023-07-06 12:24pm
https://universe.roboflow.com/sengunthar-engineering-college/lung-cancer-sdctq

Provided by a Roboflow user
License: CC BY 4.0

